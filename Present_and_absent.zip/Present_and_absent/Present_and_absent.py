# После запуска программы нужно подождать пока программа в консоли выдаст (Listen on 0.0.0.0:8080) и прописать в браузере localhost:8080
# Для использования сервера нужно скачать ngrok и в нем прописать: ngrok http -region eu 8080 или, если вы из России: ngrok http -region ap 8080
# Если вы из любой другой страны, укажите: http -region <ВАШ РЕГИОН> 8080
# Ссылка на этот сервер будет в появившемся окне (раздел Forwarding)

# Добавьте своих учеников в базу данных faces (добавляйте также людей, которые потенциально могут быть распознаны,
# но не должны учитываться как опоздавшие (к примеру, учителя, люди с параллельных классов и т.п.), подписывайте этих людей как teacher1, teacher2...)
import asyncio
from pywebio import start_server
from pywebio.output import *
from pywebio.input import *
from pywebio.session import defer_call, info as session_info, run_async, run_js
import numpy as np
import face_recognition
import cv2
import os
from datetime import datetime
import time
import re

online_users = set()

path = 'faces'
images = []
classNames = []
myList = os.listdir(path)
recognitedNames = []
f0 = open('VesDen.txt', 'w')# Также для подстраховки результат работы программы будет копироваться в этот файл

# Распознавание лиц на фотографиях, переведение их в цифровой формат и создание списка имен
for cls in myList:
    curImg = cv2.imread(f'{path}/{cls}')
    images.append(curImg)
    if re.sub(r'[^\w\s]+|[\d]+', r'',os.path.splitext(cls)[0]).strip() != "teacher":
        classNames.append(os.path.splitext(cls)[0])
    else:
        classNames.append("teacher")

#print(classNames) # Выведение списка имен (если нужно)

def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList

def markAttendance(name):
    with open("NameList.csv", "r+") as f:
        myDataList = f.readlines()
        nameList = []
        for line in myDataList:
            entry = line.split(',')
            nameList.append(entry[0])
        if name not in nameList:
            now = datetime.now()
            dtString = now.strftime("%H:%M:%S")
            f.writelines(f'\n{name}, {dtString}')

encodeListKnown = findEncodings(images)
print("Декодирование закончено")

# Подключение камеры
cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)
NTCounter=[0,0,0,0,0,0]

FirstTime = 23*60+55 # Тут меняйте время выведения списка отсутствующих учеников на нужное вам (колчиество часов *60 + количество минут)

#Раб
async def main():
    while True:
        await asyncio.sleep(1)
        success, img = cap.read()
        cv2.putText(img, "ПОЖАЛУЙСТА, СМОТРИТЕ В КАМЕРУ 2 СЕКУНДЫ", (25, 25), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 0, 255), 2)
        imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
        imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

        facesCurFrame = face_recognition.face_locations(imgS)
        encodeCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

        for encodeFace, faceLoc in zip(encodeCurFrame, facesCurFrame):
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
            faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
            #print(faceDis)
            matchIndex = np.argmin(faceDis)
            if matches[matchIndex]:
                name = classNames[matchIndex]
                #print(name)
                y1, x2, y2, x1 = faceLoc
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 255, 0), cv2.FILLED)
                counter = 0
                for i in range(len(recognitedNames)):
                    if recognitedNames[i]==name:
                        counter+=1
                if counter<1 and name!="teacher":
                    recognitedNames.append(name)
                cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                markAttendance(name)

        NowTime = int(time.strftime("%H"))*60 + int(time.strftime("%M"))

        if NowTime == FirstTime and NTCounter[0]==0:
            result=list(set(recognitedNames) ^ set(classNames))
            f0.write("Досі не прийшли (до 8:50 не прийшли):\n")
            put_markdown("Досі не прийшли (до 8:50 не прийшли):\n")
            for i in range(len(result)):
                if(result[i]!="teacher"):
                    put_markdown(result[i] + "\n")
                    f0.write(result[i] + "\n")
            f0.close()
            NTCounter[0]+=1

        cv2.imshow("YOU", img)
        cv2.waitKey(1)
if __name__ == "__main__":
    start_server(main, debug=True, port=8080, cdn=False)